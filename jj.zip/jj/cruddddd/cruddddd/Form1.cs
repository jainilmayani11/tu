﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace cruddddd
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void populate()
        {
            String constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\LENOVO\source\repos\cruddddd\cruddddd\Database1.mdf;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            string Query = "select * from student";
            SqlDataAdapter sda = new SqlDataAdapter(Query, constr);
            var ds = new DataSet();
            sda.Fill(ds);
            dgv.DataSource = ds.Tables[0];
            con.Close();
        }

        private void Btninsert_Click(object sender, EventArgs e)
        {
            this.Enabled = false;
            String constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\LENOVO\source\repos\cruddddd\cruddddd\Database1.mdf;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            String query = "Insert into student(EnrlNo,Name,Age,City)Values(@EnrlNo,@Name,@Age,@City)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@EnrlNo", txtEnrlNo.Text);
            cmd.Parameters.AddWithValue("@Name", txtName.Text);
            cmd.Parameters.AddWithValue("@Age", txtAge.Text);
            cmd.Parameters.AddWithValue("@City", txtCity.Text);
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Insertion successful", "Insertion");
            reset();
            this.Enabled = true;
            populate();

        }

        public void reset()
        {
            txtAge.Text = "";
            txtCity.Text = "";
            txtEnrlNo.Text = "";
            txtName.Text = "";
        }


        private void Btnupdate_Click(object sender, EventArgs e)
        {
            this.Enabled = false;
            String constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\LENOVO\source\repos\cruddddd\cruddddd\Database1.mdf;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            String query = "Update student set Name=@Name, Age=@Age, City=@City where EnrlNo=@EnrlNo";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@EnrlNo", txtEnrlNo.Text);
            cmd.Parameters.AddWithValue("@Name", txtName.Text);
            cmd.Parameters.AddWithValue("@Age", txtAge.Text);
            cmd.Parameters.AddWithValue("@City", txtCity.Text);
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Update successful", "Insertion");
            reset();
            this.Enabled = true;
            populate();

        }


        int key = 0;
        private void dgv_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow dgvRow = dgv.Rows[e.RowIndex];

            txtEnrlNo.Text = dgvRow.Cells[1].Value.ToString();
            txtName.Text = dgvRow.Cells[2].Value.ToString();
            txtAge.Text = dgvRow.Cells[3].Value.ToString();
            txtCity.Text = dgvRow.Cells[4].Value.ToString();

          

        }
        

        private void BtnReset_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void Btndelete_Click(object sender, EventArgs e)
        {
            this.Enabled = false;
            String constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\LENOVO\source\repos\cruddddd\cruddddd\Database1.mdf;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();

            String query = "DELETE FROM Student where EnrlNo=@EnrlNo";
           
            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@EnrlNo", txtEnrlNo.Text);
            cmd.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("Deletion successful", "Insertion");
            reset();
            this.Enabled = true;

            populate();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database1DataSet.student' table. You can move, or remove it, as needed.
            this.studentTableAdapter.Fill(this.database1DataSet.student);

        }

        private void BtnView_Click(object sender, EventArgs e)
        {
            populate();
        }

      
    }
}
