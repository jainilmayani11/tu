﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace tutorial9
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnInsert_Click(object sender, EventArgs e)
        {
            this.Enabled = false;
            String constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\LENOVO\OneDrive\Desktop\tutorial9\Database1.mdf;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            String query = "Insert into student(EnrlNo,Name,Age,City)Values(@EnrlNo,@Name,@Age,@City)";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@EnrlNo", txtEnrlNo.Text);
            cmd.Parameters.AddWithValue("@Name", txtName.Text);
            cmd.Parameters.AddWithValue("@Age", txtAge.Text);
            cmd.Parameters.AddWithValue("@City", txtCity.Text);
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Insertion successful", "Insertion");
            reset();
            this.Enabled = true;



        }

        public void reset()
        {
            txtEnrlNo.Text = "";
            txtName.Text = "";
            txtAge.Text = "";
            txtCity.Text = "";

        }
        private void BtnReset_Click(object sender, EventArgs e)
        {
            reset();
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            this.Enabled = false;
            string constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\jvnab\source\repos\tutorial9\Database1.mdf;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();

            String query = "Update Student Set Name=@Name,Age=@Age,City=@City where EnrlNo=@EnrlNo";
            SqlCommand cmd = new SqlCommand(query, con);
            cmd.Parameters.AddWithValue("@EnrlNo", txtEnrlNo.Text);
            cmd.Parameters.AddWithValue("@Name", txtName.Text);
            cmd.Parameters.AddWithValue("@Age", txtAge.Text);
            cmd.Parameters.AddWithValue("@City", txtCity.Text);
            cmd.ExecuteNonQuery();

            con.Close();

            MessageBox.Show("Update successfull", "Insertion");
            reset();
            this.Enabled = true;
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            this.Enabled = false;
            String constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\LENOVO\OneDrive\Desktop\tutorial9\Database1.mdf;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();

            String query = "DELETE FROM Student where EnrlNo=@EnrlNo";
            SqlCommand cmd = new SqlCommand(query, con);

            cmd.Parameters.AddWithValue("@Enrlno", txtEnrlNo.Text);
            cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show("Delete successfull", "Insertion");
            reset();
            this.Enabled = true;
        }
    }
}
