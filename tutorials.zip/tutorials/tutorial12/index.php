<?php
include("connection.php");
  $deleteMsg = isset($_SESSION['deleteMsg'])?$_SESSION['deleteMsg']:"";
  unset($_SESSION['deleteMsg']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
  <title>Document</title>


  <script type="text/javascript">
    $(document).ready(function() {
      $('table').DataTable({

      })
    });
  </script>


<style>
 .danger {
    border-color: #f44336;
    color: red;
  }
  
  .danger:hover {
    background: red;
    color: white;
  }
  
  .success {
    border-color: #04AA6D;
    color: green;
  }
  
  .success:hover {
    background-color: #04AA6D;
    color: white;
  }
  
  .info {
    border-color: #2196F3;
    color: dodgerblue;
  }
  
  .info:hover {
    background: #2196F3;
    color: white;
  }
  .btnrecord{
    text-align:right;
    margin-right:5px;
    margin-top:3px;
  
  }
  .cl {
   					color:green;
					background-color: whitesmoke; 
}    
</style>
 

</head>
<body>
  <h1 align="center" style="color: #FF0033">Tutorial 12</h1>

<div  class="btnrecord">
  <input type="submit" class="btn btn-primary btnrecord" onclick="location.href='registration.php'" value="Add Record"> 
 
</div>

  <table class="table table-bordered" border="2" style="background-color: white; border-color: black;" >
  <h3 class="cl text-center"><?=$deleteMsg?></h3>

  <thead class="table-dark">
    <tr align="center">
        <th>Machine</th>
        <th>Process</th>
        <th>Item</th>
        <th>Parameter</th>
        <th>Measuring Tolerance</th>
        <th>Actual Tolerance</th>
        <th>Action</th>
    </tr>
  </thead>

          
  <?php
            $sql = " SELECT tbl_ipmp.id, machine_name,process_name, item_name, parametername, lower_tolerance,upper_tolerance FROM tbl_ipmp 
                      INNER JOIN tbl_machine ON 
                      tbl_machine.id = tbl_ipmp.machine_id
                      INNER JOIN tbl_process ON 
                      tbl_process.id = tbl_ipmp.process_id
                      INNER JOIN tbl_items ON 
                      tbl_items.id = tbl_ipmp.item_id   
                      WHERE tbl_ipmp.is_delete = 0";

            $result = $db->query($sql);
            while ($row = $result->fetch_assoc()) {
            ?>
              <tr>
                <td><?= $row['machine_name'] ?></td>
                <td><?= $row['process_name'] ?></td>
                <td><?= $row['item_name'] ?></td>
                <td><?= $row['parametername'] ?></td>
                <td><?= $row['lower_tolerance'] ?> To <?= $row['upper_tolerance'] ?> </td>
                <td><?= $row['lower_tolerance'] ?> To <?= $row['upper_tolerance'] ?> </td>

                <td align="center">
                  <a href="registration.php?id=<?= $row['id'] ?>"><input type="submit" class="btn  btn-primary" id="edituser" value="Edit"></a>
                  <a  href="delete.php?id=<?= $row['id'] ?>"><input  type="button" id="deleteuser" class="btn btn-danger" value="Delete"></a>
                </td>
              
              </tr>
            <?php
            }
  ?>
</table>
<a href="../../index.html#tutorial" style="font-size:20px">Back to Website !!!</a>
  
</body>
</html>

