<?php
require "connection.php";
$id = $_POST['id'];
$firstname = $_POST['fname'];
$lastname = $_POST['lname'];
$email = $_POST['email'];
$password = $_POST['npass'];
$bio = $_POST['bio'];
$time = time();

    if ($id == '') {
        $sql = "insert into users values(NULL,'$firstname','$lastname','$email','$password','$bio','$time')";	
    } else {
        $sql = "UPDATE users set first_name='$firstname',last_name='$lastname',username='$email', password='$password',bio='$bio' where id='$id'";
    }

$db->query($sql);
header("location:index.php");

?>
