
<?php

include 'connection.php';

$id = '';
$machine_name = '';
$process_name = '';
$item_name = '';
$parametername = '';
$lower_tolerance = '';
$upper_tolerance = '';

if (isset($_GET['id'])) {
  $id = $_GET['id'];
  $sql = "SELECT tbl_ipmp.id, machine_name,process_name, item_name, parametername, lower_tolerance,upper_tolerance FROM tbl_ipmp 
      INNER JOIN tbl_machine ON 
      tbl_machine.id = tbl_ipmp.machine_id
      INNER JOIN tbl_process ON 
      tbl_process.id = tbl_ipmp.process_id
      INNER JOIN tbl_items ON 
      tbl_items.id = tbl_ipmp.item_id   
      WHERE tbl_ipmp.id = $id";
  $res = $db->query($sql);

  if ($res->num_rows) {
    $row = $res->fetch_assoc();
    $id = $row['id'];
    $machine_name = $row['machine_name'];
    $process_name = $row['process_name'];
    $item_name = $row['item_name'];
    $parametername = $row['parametername'];
    $lower_tolerance = $row['lower_tolerance'];
    $upper_tolerance = $row['upper_tolerance'];
  }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Tutorial 12</title>
  <link rel="stylesheet" href="css/styles.css">
  <script src="jquery-2.2.4.min.js"></script>
</head>
<body>



<div class="wrapper">
    <div class="title">
      Registration Form
    </div>
   <form  method="post" action="userdata.php" name="RegForm" onsubmit="return myfunction()"  id="form"> 
    <div class="form">
       <div class="inputfield">
	   		<label for="fname">machine_name</label>
            <input type="text" id="fname" name="fname" class="input" value="<?= $machine_name ?>">
       </div>  
       <div class="inputfield">
	   		<label for="lname">process_name</label>
            <input type="text" id="lname" name="lname" class="input" value="<?= $process_name ?>">
       </div>  
       <div class="inputfield">
	   		<label for="email">item_name</label>
            <input type="text" id="email" name="email" class="input" value="<?= $item_name ?>">
       </div>  
      <div class="inputfield">
	  		<label for="password">parametername</label>
            <input type="text" id="password" name="npass" class="input" value="<?= $parametername ?>">
       </div> 

       <div class="inputfield">
	  		<label for="note">lower_tolerance</label>
            <input type="text" class="input" id="note" name="lower_tolerance" rows="3" value="<?= $lower_tolerance ?>">
       </div> 


	   <div class="inputfield">
	  		<label for="note">upper_tolerance</label>
            <input type="text" class="input" id="note" name="upper_tolerance" rows="3" value="<?= $upper_tolerance ?>">
       </div>
     
      <div class="inputfield">
        <input type="submit" name="submit" value="submit" class="btn">
      </div>

      <div class="inputfield">
        <button type="button"  class="btn" onclick="history.back()">Cancel</button>
      </div>
      
      
        <a href="../../index.html#tutorial">Back To Site</a>
    </div>
  </form>
</div>	
	
</body>
</html>
<script>
    $(document).ready(function() {

      $('#form').submit(function() {

        var fname = $('#fname').val();
        var lname = $('#lname').val();
        var email = $('#email').val();
        var password = $('#password').val();
        var repassword = $('#repassword').val();
        var note = $('#note').val();

        $(".error").remove();

        if (fname.length < 1) {
          $('#fname').after('<span class="text-danger error">First name is required</span>');
          return false;
        }
        if (lname.length < 1) {
          $('#lname').after('<span class="text-danger error">Last name field required</span>');
          return false;
        }

        if (email.length < 1) {
          $('#email').after('<span class="text-danger error">Please Enter Email Address</span>');
          return false;
        } else {
          var regEx = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
          var validEmail = regEx.test(email);
          if (!validEmail) {
            $('#email').after('<span class="text-danger error">Enter a valid email</span>');
            return false;
          }
        }

        if (password.length < 8 || repassword.length < 8) {
          $('#password').after(
            '<span class="text-danger error">Password must be at least 8 characters long</span>');
          $('#repassword').after(
            '<span class="text-danger error">Password must be at least 8 characters long</span>');
          return false;
        } else if (password != repassword) {
          $('#repassword').after('<span class="text-danger error">Password dose not match</span>');
          return false;
        }

        if (note.length < 1) {
          $('#note').after('<span class="text-danger error">Please enter message</span>');
          return false;
        }
      });

    });
  </script>