<?php
session_start();

require "connection.php";
$id = isset($_GET['id']) ? $_GET['id'] : 0;
echo $id;

// Hard Delete
// $sql = "delete from tbl_ipmp where id = '$id'";

// Soft Delete
$sql = "UPDATE tbl_ipmp SET is_delete = 1 WHERE id = '$id' ";

$result = $db->query($sql);
if ($db->affected_rows) {
    $_SESSION['deleteMsg'] = "Record Deleted Successfully!!!";
    print_r($_SESSION['deleteMsg']);
    header("location:index.php");
}
