<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Tutorial 15</title>
	<link rel="stylesheet" href="css/styles.css">
  <script src="jquery-2.2.4.min.js"></script>
</head>
<body>



<div class="wrapper">
    <div class="title">
      Registration Form
    </div>
   <form  method="post" action="userdata.php" name="RegForm" onsubmit="return myfunction()"  id="form"> 
    <div class="form">
       <div class="inputfield">
          <label>Full Name</label>
          <input type="text" class="input" placeholder="Enter Your Full Name" name="Fname" id="fname" > 
       </div>  
       <div class="inputfield">
          <label>Email Address</label>
          <input type="text" class="input" placeholder="Enter Email Address" name="Email" id="email">
       </div>  
       <div class="inputfield">
          <label>Password</label>
          <input type="password" class="input" placeholder="Enter Your Password" name="Pass" id="password">
       </div>  
      <div class="inputfield">
          <label>Confirm Password</label>
          <input type="password" class="input" placeholder="Enter Your Confirm-Password" name="Cpass" id="repassword" >
       </div> 

       <div class="inputfield">
          <label>Address</label>
          <textarea  rows="5" name="Address" id="address" class="input"></textarea>
       </div> 
     
      <div class="inputfield">
        <input type="submit" name="submit" value="Add Data" class="btn">
      </div>
        <a href="../../index.html#tutorial">Back To Site</a>
    </div>
  </form>
</div>	
	
</body>
</html>
<script type="text/javascript">
	function myfunction()								 
{ 
	var  awe = /^[a-zA-Z]+$/;
	var  b = /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/;
	var  c= /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[#$^+=!*()@%&]).{8,20}$/;
	
	var fn = document.forms["RegForm"]["Fname"];
	var email = document.forms["RegForm"]["Email"];			 			 		 			 
	var add = document.forms["RegForm"]["Address"];			 	 
	var password = document.forms["RegForm"]["Pass"]; 
	var cpassword = document.forms["RegForm"]["Cpass"];	
	// var func=fn.value;		 
	if (fn.value == "")								 
	{ 
		window.alert("Full Name Is Empty."); 
		fn.focus(); 
		return false; 
	}
	else if ((fn.value.length <= 3) || (fn.value.length > 15))
	{
		window.alert("First name must be 3 or less than 15."); 
		fn.focus(); 
		return false;
	}
	if (fn.value.match(awe)) 
	{
  
		email.focus(); 
  		//return false;
    }
    else
    {
     alert("Please Enter values in Character only");
	   fn.focus();
     return false;
    }

	if (email.value == "")								 
	{ 
		window.alert("Email Address is Empty."); 
		email.focus(); 
		return false; 
	}
	if(email.value.match(b))
	{
		password.focus(); 
	} 
	else
	{
		window.alert("Please Enter Valid Email."); 
		email.focus();
		return false;
	}
	
  if(password.value =="")
	{
		window.alert("Password is Empty."); 
		password.focus(); 
		return false;
	}
	else if((password.value.length<=7) || (password.value.length>20))
	{
		window.alert("Password is must be 8 or less than 20."); 
		password.focus(); 		
		return false;
	}
	else
	{
		cpassword.focus();
	}
	
	//confirm password
	if(cpassword.value=="")
	{
		window.alert("Reenter Password Is Empty."); 
		cpassword.focus(); 		
		return false;
	}
	else if(cpassword.value != password.value)
	{
		window.alert("Reenter password is wrong."); 
		cpassword.focus(); 		
		return false;
	}
	if (add.value == "")								 
	{ 
		window.alert("Address Is Empty."); 
		add.focus(); 
		return false; 
	}
	//password
	
	else{
		//alert("Succesfully Register");
	}
}
</script>

<!-- <script type="text/javascript">
    
$(document).ready(function() {
      
      $('#form').submit(function(e) {
      e.preventDefault();
    
      var fname = $('#fname').val();
      var email = $('#email').val();
      var password = $('#password').val();
      var repassword = $('#repassword').val();
      var address=$('#address').val();

      
      $(".error").remove();
   
      if (fname.length < 1) {
        $('#fname').after('<span class="error" style="color:red;">Full Name field is required</span>');
      }

	  
      if (address.length == "") {
        $('#address').after('<span class="error" style="color:red;">Address field is required</span>');
      }
          
      if (email.length < 1) {
        $('#email').after('<span class="error" style="color:red;">Email field is required</span>');
      } 
      else {
      var regEx = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
      var validEmail = regEx.test(email);
      if (!validEmail) {
          $('#email').after('<span class="error" style="color:red;">Enter a valid email</span>');
      }
      }
      if (password.length < 8 ){
       $('#password').after('<span class="error" style="color:red;">Password must be at least 8 characters long</span>');
      }
      if (repassword.length < 8) {
      $('#repassword').after('<span class="error" style="color:red;">Confirm Password must be at least 8 characters long</span>');
      }
      else if(password!=repassword)
      {
        $('#repassword').after('<span class="error" style="color:red;">Password dose not match</span>');
      }
      else{
     // alert("Succesfully Register");
    }
	 
      }); 
	 
     
    });

</script> -->