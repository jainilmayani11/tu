<?php

$con=mysqli_connect("localhost","root","","tutorial11");

/*$q="create database School";
	mysqli_query($con,$q);*/
?>