<?php session_start(); /* Starts the session */

/* Check Login form submitted */	
if(isset($_POST['Submit'])){
   
    /* Check and assign submitted Username and Password to new variable */
    $Username = isset($_POST['Username']) ? $_POST['Username'] : '';
    $Password = isset($_POST['Password']) ? $_POST['Password'] : '';
    
    if($Username == 'Jainil Mayani'  && $Password == '123456'){

        $_SESSION['Username']=$Username;
        header('location:index.php');

    }
    else{
        echo '<script>alert("Email & Password is Incorrect");</script>';
        echo '<script type="text/javascript">';
        echo 'window.location.href="login.php"';
        echo '</script>';
    }
}
?>