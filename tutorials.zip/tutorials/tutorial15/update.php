<?php

require "include/connection.php";

 if (isset($_POST['submit'])) 
 {
    $fullName=@$_POST['Fname'];
    $emailid=@$_POST['Email'];
    $password=@$_POST['Pass'];
    $cpassword=@$_POST['Cpass'];
    $address=@$_POST['Address'];
    

	$query="UPDATE registration set FullName='$fullName', Password='$password', CPassword='$cpassword', Address='$address' where Email='$emailid'";
 	if (mysqli_query($con,$query)) 
 	{
 		echo "<script>window.location='index.php';</script>";
 	}
 	else
 	{
 		echo "<script>alert('Data Upadation Failed !');
 		window.location='index.php';</script>";	
 	}
 }

?>