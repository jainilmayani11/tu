
<!DOCTYPE html>
<html lang="en">
 
<?php 
    session_start();
    $message = isset($_SESSION['logoutmsg'])?$_SESSION['logoutmsg']:"";
    unset($_SESSION['logoutmsg']);
?>

<?php
    
        $user = isset($_COOKIE['Username']) ? $_COOKIE['Username'] : "";
        $pass = isset($_COOKIE['Password']) ? $_COOKIE['Password'] : "";
        $remember = isset($_COOKIE['Username']) ? 'checked' : "";

    
?>

<head>
   <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login Form</title>
	<link rel="stylesheet" href="css/styles.css">
   <script src="jquery-2.2.4.min.js"></script>

   <script>
		$(document).ready(function() {
		
		$('#form').submit(function() {
			$('.error').remove();
			var username = $('#Username').val();
			
			var password = $('#Password').val();
		
			if (username=="" || password=="") {
				if(username=="")
					$('#Username').after('<span class="error" style="color:red;">This Username field is required</span>');
				if(password=="")
					$('#Password').after('<span class="error" style="color:red;">This Password field is required</span>');
				return false;
			}
		});
		
		});
	</script>

   <style>
      .title_logout{
         color: red;
         text-align: center;
         font-size: 24px;
         font-weight: 700;
       }
   </style>

</head>
<body>

<div class="wrapper" style="margin-top: 15%;">
    <div class="title">Login Form</div>
    <div class="title_logout">
       <h3><?= $message ?></h3>
    </div>

    <form action="validateuser.php" method="post" id="form">
    <?php if(isset($msg)){?>
		<tr>
		  <td colspan="2" align="center"><?php echo $msg;?></td>
		</tr>
		<?php } ?>
    <div class="form">

       <div class="inputfield">
          <label>Username</label><br>
          <input type="text" class="input" placeholder="Jainil@gmail.com" name="Username" value=<?=$user?>>
       </div>

       <div class="inputfield">
          <label>Password</label><br>
          <input type="password" class="input" placeholder="123456" name="Password" value=<?=$pass?>>
       </div> 

       <div class="inputfield">
          <input type="checkbox" name="remember" <?=$remember?> >
          <label for="remember"> Remember Me. </label>
	  	</div>

       <div class="inputfield">
        <input type="submit" value="login" class="btn" name="Submit" id="login">
      </div> 

       <a href="registration.php" >Don't have Account</a><br><br>
       <a href="../../index.html#tutorial">Back To Site !!</a>
       
  </div>
</form>	
</body>
</html>


 