<?php session_start();
if(isset($_POST['Submit'])){ 
    
    $Username = (isset($_POST['Username']) ? trim($_POST['Username']) : "");
    $Password = (isset($_POST['Password']) ? trim($_POST['Password']) : "");
    
    if($Username == 'Jainil@gmail.com' && $Password == '123456')
    {

        $_SESSION['Username']=$Username;

        if(isset($_POST['remember']))
        {
            setcookie('Username',$Username,time()+60*60*7);
            setcookie('Password',$Password,time()+60*60*7);
        }
        else{
            setcookie('Username',$Username,time());
            setcookie('Password',$Password,time());
        }

        header('location:index.php');
    } 
    else 
    {
       echo '<script>alert("Email & Password is Incorrect !");</script>';
       echo '<script type="text/javascript">';
       echo 'window.location.href="index.php";';
       echo '</script>';
    }
} 
?>  