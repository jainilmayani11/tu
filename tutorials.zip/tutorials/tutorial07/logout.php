<?php session_start(); /* Starts the session */

unset($_SESSION['Username']); 
$_SESSION['logoutmsg']='Logout Sucessfull';
header("location:index.php"); /* Destroy started session */

if(isset($_COOKIE['Username']) && isset($_COOKIE['Password']))
{
    $Username = $_COOKIE['Username'];
    $Password = $_COOKIE['Password'];

}
header("location:index.php");
exit;
?>  