<?php session_start(); 

if(!isset($_SESSION['Username']))
{
   header('location:login.php');
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
  <title>Document</title>
<style>
 .danger {
    border-color: #f44336;
    color: red;
  }
  
  .danger:hover {
    background: red;
    color: white;
  } 
  
  .success {
    border-color: #04AA6D;
    color: green;
  }
  
  .success:hover {
    background-color: #04AA6D;
    color: white;
  }
  
  .info {
    border-color: #2196F3;
    color: dodgerblue;
  }
  
  .info:hover {
    background: #2196F3;
    color: white;
  }
</style>
 

</head>
<body>
  <h1 align="center" style="color: #FF0033">Registration Data</h1>
  <table class="table table-bordered" border="2" style="background-color: white; border-color: black;">
  <thead class="table-dark">
      <tr align="center">
        <th>Full Name</th>
        <th>Email</th>
        <th>Password</th>
        <th>Country</th>
        <th>State</th>
        <th>City</th>
        <th>Zipcode</th>
        <th>Age</th>
        <th>Birthday</th>
        <th>Action</th>
        <th><a href="../Tutorial3/registration.html"><button class="btn info">Add</button></a>
            <a href="logout.php"><input  type="button" class="btn danger btn-delete" value="Logout"></a>
        </th>
      </tr>  
      </th>
      </tr>
    </thead>
    <tbody > 
      <tr align="center">
          <td >Jainil Mayani</td>
          <td>jmayani787@rku.ac.in</td>
          <td>********</td>
          <td>India</td>
          <td>Gujarat</td>
          <td>Rajkot</td>
          <td>360022</td>
          <td>20</td>
          <td>06/04/2002</td>
          <td><button class="btn success">Edit</button></td>
          <td><button class="btn danger btn-delete">Delete</button></td>
       </tr>
       <tr align="center">
          <td>Jainil Mayani</td>
          <td>jmayani787@rku.ac.in</td>
          <td>********</td>
          <td>India</td>
          <td>Gujarat</td>
          <td>Rajkot</td>
          <td>360022</td>
          <td>20</td>
          <td>06/04/2002</td>
          <td><button class="btn success">Edit</button></td>
          <td><button class="btn danger btn-delete">Delete</button></td>
       </tr>
       <tr align="center">
          <td>Jainil Mayani</td>
          <td>jmayani787@rku.ac.in</td>
          <td>********</td>
          <td>India</td>
          <td>Gujarat</td>
          <td>Rajkot</td>
          <td>360022</td>
          <td>20</td>
          <td>06/04/2002</td>
          <td><button class="btn success">Edit</button></td>
          <td><button class="btn danger btn-delete">Delete</button></td>
       </tr>
       <tr align="center">
          <td>Jainil Mayani</td>
          <td>jmayani787@rku.ac.in</td>
          <td>********</td>
          <td>India</td>
          <td>Gujarat</td>
          <td>Rajkot</td>
          <td>360022</td>
          <td>20</td>
          <td>06/04/2002</td>
          <td><button class="btn success">Edit</button></td>
          <td><button class="btn danger btn-delete">Delete</button></td>
       </tr>
       <tr align="center">
          <td>Jainil Mayani</td>
          <td>jmayani787@rku.ac.in</td>
          <td>********</td>
          <td>India</td>
          <td>Gujarat</td>
          <td>Rajkot</td>
          <td>360022</td>
          <td>20</td>
          <td>06/04/2002</td>
          <td><button class="btn success">Edit</button></td>
          <td><button class="btn danger btn-delete">Delete</button></td>
       </tr>
       <tr align="center">
          <td>Jainil Mayani</td>
          <td>jmayani787@rku.ac.in</td>
          <td>********</td>
          <td>India</td>
          <td>Gujarat</td>
          <td>Rajkot</td>
          <td>360022</td>
          <td>20</td>
          <td>06/04/2002</td>
          <td><button class="btn success">Edit</button></td>
          <td><button class="btn danger btn-delete">Delete</button></td>
       <tr align="center">
          <td>Jainil Mayani</td>
          <td>jmayani787@rku.ac.in</td>
          <td>********</td>
          <td>India</td>
          <td>Gujarat</td>
          <td>Rajkot</td>
          <td>360022</td>
          <td>20</td>
          <td>06/04/2002</td>
          <td><button class="btn success">Edit</button></td>
          <td><button class="btn danger btn-delete">Delete</button></td>
      </tr>
      <tr align="center">
          <td>Jainil Mayani</td>
          <td>jmayani787@rku.ac.in</td>
          <td>********</td>
          <td>India</td>
          <td>Gujarat</td>
          <td>Rajkot</td>
          <td>360022</td>
          <td>20</td>
          <td>06/04/2002</td>
          <td><button class="btn success">Edit</button></td>
          <td><button class="btn danger btn-delete">Delete</button></td>
     </tr>
      </tbody>
</table>
      <a href="../../index.html#tutorial" style="font-size:20px">Back to Website !!!</a>
  
</body>
</html>

