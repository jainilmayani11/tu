<!DOCTYPE html>
<html lang="en">
<head>

   
   <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Tutorial 08</title>
	<link rel="stylesheet" href="css/styles.css">
   <script src="jquery-2.2.4.min.js"></script>
</head>
<body>
   
<div class="wrapper" style="margin-top: 10%;">

<?php if(isset($_GET['error'])){?>
        <p style="color:red"> <?php echo $_GET['error']; ?></p>
        <?php } ?>

<form action="upload.php" method="post" enctype="multipart/form-data">
    <div class="form">
        <div class="inputfield">
            <h1><b><i> Select Picture. </i></b></h1><br>
            <div class="form-group">
                <div class="col-md-12">
                    <input type="file" name="my_image"/>
                </div>
            </div>
        </div>  

        <div class="inputfield">
            <div class="inputfield">
                    <input type="submit" class="btn btn-info" name="submit" value="Upload"/>
                </div><br>
                <div class="col-md-12">
             <a href="view.php" class="backtosite" >Want to View Photos.</a>
            </div>
        </div> 
       <a href="../../index.html#tutorial">Back To Site !!</a>
        </div>
</form>	
</body>
</html>