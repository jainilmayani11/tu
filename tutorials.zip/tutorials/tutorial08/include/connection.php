<?php

$con=mysqli_connect("localhost","root","","tutorial08");

/*$q="create database School";
	mysqli_query($con,$q);*/
?>