<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Registration Form</title>
	<link rel="stylesheet" href="css/styles.css">
  <script src="jquery-2.2.4.min.js"></script>
</head>
<body>



<div class="wrapper">
    <div class="title">
      Registration Form
    </div>
   <form action="#" method="post" id="form"> 
    <div class="form">
       <div class="inputfield">
          <label>Full Name</label>
          <input type="text" class="input" placeholder="Enter Your Full Name" id="fname"> 
       </div>  
       <div class="inputfield">
          <label>Email Address</label>
          <input type="text" class="input" placeholder="Enter Email Address" id="email">
       </div>  
       <div class="inputfield">
          <label>Password</label>
          <input type="password" class="input" placeholder="Enter Your Password" id="password">
       </div>  
      <div class="inputfield">
          <label>Confirm Password</label>
          <input type="password" class="input" placeholder="Enter Your Confirm-Password" id="repassword" >
       </div> 
        <div class="inputfield">
          <label>Age</label>
          <input type="number" class="input" placeholder="Enter Your Age" id="age">
        </div>

        <div class="inputfield">
          <label>your birthdate</label>
          <input class="input" type="date" placeholder="YYYY-MM-DD" data-date-split-input="true" id="birthdate" />
        </div>

       <div class="inputfield">
        <label>Select Country</label>
            <select id="countySel" size="1" class="input">
              <option value="" selected="selected" id="country">-- Select Country --</option>
            </select>
        </div>

        <div class="inputfield">
          <label>Select State</label>
           <select id="stateSel" size="1" class="input">
              <option value="" selected="selected" id="state">-- Select State--</option>
            </select>
        </div>

        <div class="inputfield">
          <label>Select City</label>
          <select id="citySel" size="1" class="input">
          <option value="" selected="selected" id="city">-- Select City--</option>
          </select>
        </div>

        <div class="inputfield">
          <label>Select Zipcode</label>
          <select id="zipSel" size="1" class="input">
            <option value="" selected="selected" id="zip">-- Select Zip--</option>
          </select>
       </div>
       
      
        <div class="inputfield">
              <label>Profile Photo</label>
              <input type="file" id="imageUpload" name="channel-img"  class="input">
        </div> 
    
        <div class="inputfield">
            <label>Note</label>
            <textarea id="note" rows="5" cols="50" class="input"> </textarea>
        </div>
     
      <div class="inputfield">
        <input type="submit" value="Register" class="btn">
      </div>
         <a href="login.php">Login Here</a>
    </div>
  </form>
</div>	


<script>
       var countryStateInfo = {
    
                        "India": {
                          "Gujarat": {
                                            "Rajkot" : ["360011", "360004"],
                                            "Vadodara" : ["390011", "390020"],
                                            "Surat" : ["395006", "395002"]
                                            },
                                "Assam": {
                                          "Dispur": ["781005"],
                                          "Guwahati" : ["781030", "781030"]
                                          }
                               
                                  }
                                }


window.onload = function () {
  
  //Get html elements
  var countySel = document.getElementById("countySel");
  var stateSel = document.getElementById("stateSel"); 
  var citySel = document.getElementById("citySel");
  var zipSel = document.getElementById("zipSel");
  
  //Load countries
  for (var country in countryStateInfo) {
    countySel.options[countySel.options.length] = new Option(country, country);
  }
  
  //County Changed
  countySel.onchange = function () {
     
     stateSel.length = 1; // remove all options bar first
     citySel.length = 1; // remove all options bar first
     zipSel.length = 1; // remove all options bar first
     
     if (this.selectedIndex < 1)
       return; // done
     
     for (var state in countryStateInfo[this.value]) {
       stateSel.options[stateSel.options.length] = new Option(state, state);
     }
  }
  
  //State Changed
  stateSel.onchange = function () {    
     
     citySel.length = 1; // remove all options bar first
     zipSel.length = 1; // remove all options bar first
     
     if (this.selectedIndex < 1)
       return; // done
     
     for (var city in countryStateInfo[countySel.value][this.value]) {
       citySel.options[citySel.options.length] = new Option(city, city);
     }
  }
  
  //City Changed
  citySel.onchange = function () {
    zipSel.length = 1; // remove all options bar first
    
    if (this.selectedIndex < 1)
      return; // done
    
    var zips = countryStateInfo[countySel.value][stateSel.value][this.value];
    for (var i = 0; i < zips.length; i++) {
      zipSel.options[zipSel.options.length] = new Option(zips[i], zips[i]);
    }
  } 
}


$(document).ready(function() {
      
      $('#form').submit(function(e) {
      e.preventDefault();
    
      var fname = $('#fname').val();
      var email = $('#email').val();
      var password = $('#password').val();
      var repassword = $('#repassword').val();
      var age=$('#age').val();
      var birthdate=$('#birthdate').val();
      var state=$('#state').val();
      var country=$('#country').val();
      var city=$('#city').val();
      var note=$('#note').val();
      var imageUpload=$('#imageUpload').val();
      var countySel = $("#countySel").val();
      var stateSel = $("#stateSel").val();
      var citySel = $("#citySel").val();
      var zipSel = $("#zipSel").val();


      
      $(".error").remove();
   
      if (fname.length < 1) {
        $('#fname').after('<span class="error" style="color:red;">Full Name field is required</span>');
      }
     
          
      if (email.length < 1) {
        $('#email').after('<span class="error" style="color:red;">Email field is required</span>');
      } else {
      var regEx = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
      var validEmail = regEx.test(email);
      if (!validEmail) {
          $('#email').after('<span class="error" style="color:red;">Enter a valid email</span>');
      }
      }
      if (password.length < 8 ){
       $('#password').after('<span class="error" style="color:red;">Password must be at least 8 characters long</span>');
      }
      if (repassword.length < 8) {
      $('#repassword').after('<span class="error" style="color:red;">Confirm Password must be at least 8 characters long</span>');
      }
      else if(password!=repassword)
      {
        $('#repassword').after('<span class="error" style="color:red;">Password dose not match</span>');
      }
      if (age.length < 1) {
      $('#age').after('<span class="error" style="color:red;">Age field is required</span>');
      }
      if (birthdate.length < 1) {
      $('#birthdate').after('<span class="error" style="color:red;">Birthdate field is required</span>');
      }
     
      
      if (countySel == "") {
      $('#countySel').after('<span class="error" style="color:red;">Country field is required</span>');
      }
      if (stateSel == "") {
      $('#stateSel').after('<span class="error" style="color:red;">State field is required</span>');
      }
      if (citySel == "") {
      $('#citySel').after('<span class="error" style="color:red;">City field is required</span>');
      }
      if (zipSel == "") {
      $('#zipSel').after('<span class="error" style="color:red;">Zipcode field is required</span>');
      }
      if (imageUpload.length < 1) {
      $('#imageUpload').after('<span class="error" style="color:red;">Image Upload field is required</span>');
      }

      if (note.length == "") {
        alert("HIIII");
      $('#note').after('<span class="error" style="color:red;">Note field is required</span>');
      }
      });   
     
    });

</script>
	
</body>
</html>