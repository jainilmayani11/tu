<?php session_start(); /* Starts the session */

if(!isset($_SESSION['Username']))
{
   header('location:login.php');
}
unset($_SESSION['Username']); 
$_SESSION['logoutmsg']='Logout Sucessfull';
header("location:index.php");
exit;
?>
  