<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Simple Interest Form</title>
	<link rel="stylesheet" href="css/styles.css">
   <script src="jquery-2.2.4.min.js"></script>
</head>
<body>

<div class="wrapper" style="margin-top: 10%;">
    <div class="title">
    Simple Interest Form
    </div>
<form action="result.php" method="post" id="form">
    <div class="form">
       <div class="inputfield">
          <label >Principle</label><br>
          <input type="Number" name="amount" class="input" placeholder="Enter Principle" required="">
       </div>  

       <div class="inputfield">
          <label>Rate Of Interest</label><br>
          <input type="Number" name="rate" class="input" placeholder="Enter Rate Of Interest" required="">
       </div> 

       <div class="inputfield">
          <label>Number of Years</label><br>
          <input type="Number" name="year" class="input" placeholder="Enter Number of Years" reqired=""> 
       </div>

       <div class="inputfield">
        <input type="submit" name="calculate" value="Calculate" class="btn" id="login">
      </div> 
       <a href="../../index.html">Back To Site</a>
      </div>
</form>	
</body>
</html>