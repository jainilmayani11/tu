<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Result</title>
	<link rel="stylesheet" href="css/styles.css">
   <script src="jquery-2.2.4.min.js"></script>
</head>
<body>

<div class="wrapper" style="margin-top: 10%;">
    <div class="title">Simple Interest Result</div>
<form action="result.php" method="post" id="form">
    <div class="form">
         

        <div class="inputfield">
          <label>Principle :  <?php $amount=$_POST['amount']; echo $amount ?></label><br>

       </div>

       <div class="inputfield">
          <label>Rate Of Interest : <?php $rate=$_POST['rate']; echo $rate ?></label><br>
       </div> 

       <div class="inputfield">
         <label>Number of Years : <?php $year=$_POST['year']; echo $year ?></label><br>
       </div>

       <div class="inputfield">
         <b><label>Simple Interest is : <?php $result=$amount*$rate*$year/100; echo $result; ?></label></b><br><br>
       </div>

      <a href="index.php">Calculate Again</a><br><br>
       <a href="../../index.html">Back To Site</a>
      </div>
</form>	
</body>
</html>