<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Tutorial 12</title>
	<link rel="stylesheet" href="css/styles.css">
  <script src="jquery-2.2.4.min.js"></script>
</head>
<body>



<div class="wrapper">
    <div class="title">Update Your Profile</div>

    <?php
    require "include/connection.php";

    $n=@$_REQUEST['email'];
    //echo $n;
        $q="select * from registration where Email='$n'";
        $res=mysqli_query($con,$q);
        while ($m=mysqli_fetch_array($res))
	{
        
		?>
        

   <form  method="post" action="update.php" name="RegForm" id="form"> 
    <div class="form">
       <div class="inputfield">
          <label>Full Name</label>
          <input type="text" class="input" placeholder="Enter Your Full Name" value="<?php echo $m[0];?>" name="Fname" id="fname" > 
       </div>  
       <div class="inputfield">
          <label>Email Address</label>
          <input type="text" class="input" placeholder="Enter Email Address" value="<?php echo $m[1];?>" name="Email" id="email" readonly>
       </div>  
       <div class="inputfield">
          <label>Password</label>
          <input type="password" class="input" placeholder="Enter Your Password" value="<?php echo $m[2];?>" name="Pass" id="password">
       </div>  
      <div class="inputfield">
          <label>Confirm Password</label>
          <input type="password" class="input" placeholder="Enter Your Confirm-Password" value="<?php echo $m[3];?>" name="Cpass" id="repassword" >
       </div> 

       <div class="inputfield">
          <label>Address</label>
          <input type="text" name="Address" value="<?php echo $m[4];?>"  id="address" class="input">
       </div> 
     
      <div class="inputfield">
        <input type="submit" name="submit" value="Update" class="btn">
      </div>
        <a href="../../index.html#tutorial">Back To Site</a>
    </div>
  </form>

  <?php

	}
  ?>

</div>	
	
</body>
</html>
