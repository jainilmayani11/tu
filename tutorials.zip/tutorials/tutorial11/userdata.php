<?php

include("include/connection.php");


$fullName=$_POST['Fname'];
$emailid=$_POST['Email'];
$password=$_POST['Pass'];
$cpassword=$_POST['Cpass'];
$address=$_POST['Address'];


$query= "insert into registration values('$fullName','$emailid','$password','$cpassword','$address');";
 
if(isset($_POST['submit']))
{	
	mysqli_query($con,$query);
	echo "<script>window.location='index.php';</script>";
}

?>