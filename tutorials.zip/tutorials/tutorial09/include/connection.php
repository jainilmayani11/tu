<?php
$db = new mysqli("localhost","root","","tutorial09");
?>